BUDDIES POS - ANDROID STUDIO PROJECT SOURCE

This is an Android Studio project shell around the Buddies POS offline-first HTML prototype.
It is source code, not a compiled APK.

Build APK:
1. Install Android Studio (current stable) on a computer.
2. Open this folder as an existing project.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK path (usually app/build/outputs/apk/debug/app-debug.apk).

Current functionality:
- Mobile POS menu and billing
- Zinger Burger Rs 350; Chicken Burger Rs 400; Beef Burger Rs 500; Fries Rs 200; Drinks Rs 100
- Cash, EasyPaisa/JazzCash, Bank Transfer, Card Payment
- Change calculation, local order history
- Buddies, 03038066385, Wah Cantt
- Receipt preview and Android print/save-PDF flow

Not yet implemented:
- Native Bluetooth thermal printer pairing/SDK integration (80mm layout is included, but direct printer printing needs printer model/SDK and device testing)
- Staff authentication and role permissions
- Cloud database, online backup and multi-device sync
- Secure payment gateway integration (payment methods are recorded as tender types; no money is transferred)

Local orders are stored in WebView local storage on the device. Clearing app data can erase them. Back up before using for live business.
